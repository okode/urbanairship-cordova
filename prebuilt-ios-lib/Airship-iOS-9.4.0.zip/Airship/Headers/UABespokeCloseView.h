/* Copyright 2018 Urban Airship and Contributors */

#import <UIKit/UIKit.h>

/**
 * A circle with an X in it, drawn to fill the frame.
 */
@interface UABespokeCloseView : UIView

@end
